<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WC_Gateway_VLinkPay extends WC_Payment_Gateway {

    // === Constants ===

    const PAYMENT_INIT_PATH = '/embedded/payment-init';
    const REDEEM_PATH       = '/gifthubs/public/merchant/redeem';
    const API_TIMEOUT       = 45;
    const TRANSIENT_TTL     = 10 * MINUTE_IN_SECONDS;
    const TRANSIENT_PREFIX  = 'vlinkpay_url_';
    const ACTION_LAUNCH     = 'launch';
    const ACTION_RETURN     = 'return';

    // === Configuration ===

    /**
     * Initialises the VLinkPay payment gateway.
     *
     * Sets gateway properties, loads settings, and registers the admin
     * options save hook.
     *
     * @return void
     */
    public function __construct() {
        $this->id                 = 'vlinkpay';
        $this->icon               = '';
        $this->has_fields         = false;
        $this->method_title       = __( 'VLinkPay Gateway', 'vlinkpay-gateway' );
        $this->method_description = __( 'Secure payment gateway via VLinkPay.', 'vlinkpay-gateway' );

        $this->init_form_fields();
        $this->init_settings();

        $this->title       = $this->get_option( 'title' );
        $this->description = $this->get_option( 'description' );
        $this->enabled     = $this->get_option( 'enabled' );
        $this->merchant_id = $this->get_option( 'merchant_id' ); // maps to merchantRefCode
        $this->client_id   = $this->get_option( 'client_id' );   // maps to apiKey
        $this->secret_key  = $this->get_option( 'secret_key' );  // reserved for direct payment

        add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
    }

    /**
     * Defines the admin settings fields for the gateway configuration screen.
     *
     * @return void
     */
    public function init_form_fields() {
        $this->form_fields = array(
            'enabled' => array(
                'title'   => __( 'Enable/Disable', 'vlinkpay-gateway' ),
                'type'    => 'checkbox',
                'label'   => __( 'Enable VLinkPay Payment', 'vlinkpay-gateway' ),
                'default' => 'no',
            ),
            'title' => array(
                'title'       => __( 'Title', 'vlinkpay-gateway' ),
                'type'        => 'text',
                'description' => __( 'Payment method title shown to the customer at checkout.', 'vlinkpay-gateway' ),
                'default'     => __( 'VLinkPay Payment', 'vlinkpay-gateway' ),
                'desc_tip'    => true,
            ),
            'description' => array(
                'title'       => __( 'Description', 'vlinkpay-gateway' ),
                'type'        => 'textarea',
                'description' => __( 'Payment method description shown to the customer at checkout.', 'vlinkpay-gateway' ),
                'default'     => __( 'Pay securely via VLinkPay.', 'vlinkpay-gateway' ),
            ),
            'merchant_id' => array(
                'title'       => __( 'Merchant ID', 'vlinkpay-gateway' ),
                'type'        => 'text',
                'description' => __( 'Your VLinkPay Merchant Referral Code.', 'vlinkpay-gateway' ),
                'default'     => '',
                'desc_tip'    => true,
            ),
            'client_id' => array(
                'title'       => __( 'Client ID', 'vlinkpay-gateway' ),
                'type'        => 'text',
                'description' => __( 'Your VLinkPay API Key for the embedded payment flow.', 'vlinkpay-gateway' ),
                'default'     => '',
                'desc_tip'    => true,
            ),
            'secret_key' => array(
                'title'       => __( 'Secret Key', 'vlinkpay-gateway' ),
                'type'        => 'password',
                'description' => __( 'Reserved for the VLinkPay direct payment API.', 'vlinkpay-gateway' ),
                'default'     => '',
                'desc_tip'    => true,
            ),
        );
    }

    // === Payment Processing ===

    /**
     * Processes the payment when the customer places an order.
     *
     * Builds a signed VLinkPay payment URL, stores it in a transient, and
     * redirects the customer to the intermediate launch page. Avoids JS
     * interception and works with both classic and block checkout.
     *
     * @param  int   $order_id The WooCommerce order ID.
     * @return array           Result array with 'result' and 'redirect' keys.
     */
    public function process_payment( $order_id ) {
        $order = wc_get_order( $order_id );

        $merchant_ref_code   = $this->merchant_id;
        $api_key             = $this->client_id;
        $amount              = number_format( (float) $order->get_total(), 2, '.', '' );
        $merchant_order_code = (string) $order_id;
        $email               = $order->get_billing_email();
        $timestamp           = time();

        $callback_base = defined( 'VLINKPAY_CALLBACK_BASE' ) ? trailingslashit( VLINKPAY_CALLBACK_BASE ) : home_url( '/' );
        $order_redirect_url = add_query_arg(
            array(
                'vlinkpay_action' => 'return',
                'order_id'        => $order_id,
                'order_key'       => $order->get_order_key(),
            ),
            $callback_base
        );

        // NOTE: md5() is required by the VLinkPay API checksum spec — do not change.
        $checksum = md5( implode( '|', array(
            $amount,
            $merchant_order_code,
            $email,
            $merchant_ref_code,
            $timestamp,
            $order_redirect_url,
            $api_key,
        ) ) );

        $payment_url = add_query_arg(
            array(
                'amount'            => $amount,
                'merchantOrderCode' => $merchant_order_code,
                'email'             => $email,
                'merchantRefCode'   => $merchant_ref_code,
                'timestamp'         => $timestamp,
                'checksum'          => $checksum,
                'orderRedirectUrl'  => $order_redirect_url,
            ),
            VLINKPAY_BASE_URL . self::PAYMENT_INIT_PATH
        );

        // Store the signed URL — consumed by handle_vlinkpay_launch().
        set_transient( self::TRANSIENT_PREFIX . wp_hash( (string) $order_id ), $payment_url, self::TRANSIENT_TTL );

        $order->add_order_note( __( 'Customer directed to VLinkPay embedded payment page.', 'vlinkpay-gateway' ) );

        return array(
            'result'   => 'success',
            'redirect' => add_query_arg(
                array(
                    'vlinkpay_action' => 'launch',
                    'order_id'        => $order_id,
                    'order_key'       => $order->get_order_key(),
                ),
                home_url( '/' )
            ),
        );
    }

    // === Request Handlers ===

    /**
     * Renders the self-contained modal page containing the VLinkPay iframe.
     *
     * Called when vlinkpay_action=launch is present. Validates the order key,
     * retrieves and consumes the transient URL, then outputs a full HTML page.
     * Terminates execution via exit.
     *
     * @return void
     */
    public function handle_vlinkpay_launch() {
        $order_id  = isset( $_GET['order_id'] )  ? absint( $_GET['order_id'] ) : 0;
        $order_key = isset( $_GET['order_key'] ) ? sanitize_text_field( $_GET['order_key'] ) : '';

        $order = $order_id ? wc_get_order( $order_id ) : null;

        if ( ! $order || ! hash_equals( $order->get_order_key(), $order_key ) ) {
            wp_die( esc_html__( 'Invalid payment request.', 'vlinkpay-gateway' ) );
        }

        $transient_key = self::TRANSIENT_PREFIX . wp_hash( (string) $order_id );
        $payment_url   = get_transient( $transient_key );

        if ( ! $payment_url ) {
            error_log( sprintf( '[VLinkPay] Transient expired or missing for order #%d.', $order_id ) );
            wp_die( esc_html__( 'Payment session expired. Please return to the store and try again.', 'vlinkpay-gateway' ) );
        }

        delete_transient( $transient_key );

        $site_name = esc_html( get_bloginfo( 'name' ) );
        $origin    = esc_js( home_url() );
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <title><?php echo $site_name; ?> &mdash; <?php esc_html_e( 'Secure Payment', 'vlinkpay-gateway' ); ?></title>
            <link rel="stylesheet" href="<?php echo esc_url( VLINKPAY_PLUGIN_URL . 'assets/css/vlinkpay-modal.css' ); ?>">
        </head>
        <body>
            <div class="modal-box">
                <div id="vlinkpay-spinner">
                    <div class="spin"></div>
                    <p><?php esc_html_e( 'Connecting to VLinkPay...', 'vlinkpay-gateway' ); ?></p>
                </div>
                <iframe
                    id="vlinkpay-iframe"
                    src="<?php echo esc_attr( $payment_url ); ?>"
                    allowpaymentrequest
                ></iframe>
            </div>
            <script>
                document.getElementById('vlinkpay-iframe').addEventListener('load', function () {
                    var spinner = document.getElementById('vlinkpay-spinner');
                    if (spinner) spinner.style.display = 'none';
                });

                window.addEventListener('message', function (e) {
                    if (e.origin !== '<?php echo $origin; ?>') return;
                    var data = e.data;
                    if (data && (data.action === 'vlinkpay_complete' || data.action === 'vlinkpay_error')) {
                        if (data.redirect) window.location.href = data.redirect;
                    }
                });
            </script>
        </body>
        </html>
        <?php
        exit;
    }

    /**
     * Handles the return callback from VLinkPay after payment completion.
     *
     * Called when vlinkpay_action=return is present. Validates the order key,
     * calls the VLinkPay redeem API, marks the order as complete or on-hold,
     * and posts a message to the parent window. Terminates via exit (through
     * output_postmessage_page).
     *
     * @return void
     */
    public function handle_vlinkpay_return() {
        $order_id    = isset( $_GET['order_id'] )   ? absint( $_GET['order_id'] ) : 0;
        $order_key   = isset( $_GET['order_key'] )  ? sanitize_text_field( $_GET['order_key'] ) : '';
        $redeem_code = isset( $_GET['redeemCode'] ) ? sanitize_text_field( $_GET['redeemCode'] ) : '';

        $order = $order_id ? wc_get_order( $order_id ) : null;

        if ( ! $order || ! hash_equals( $order->get_order_key(), $order_key ) || empty( $redeem_code ) ) {
            error_log( sprintf(
                '[VLinkPay] Invalid return request — order_id: %d, key_match: %s, has_redeem_code: %s.',
                $order_id,
                ( $order && hash_equals( $order->get_order_key(), $order_key ) ) ? 'yes' : 'no',
                empty( $redeem_code ) ? 'no' : 'yes'
            ) );
            $this->output_postmessage_page( 'vlinkpay_error', '' );
            return;
        }

        $redeem_endpoint = VLINKPAY_BASE_URL . self::REDEEM_PATH;

        if ( ! wp_http_validate_url( $redeem_endpoint ) ) {
            error_log( '[VLinkPay] Invalid redeem endpoint URL: ' . $redeem_endpoint );
            $order->update_status( 'on-hold', __( 'Payment gateway configuration error — invalid API URL.', 'vlinkpay-gateway' ) );
            $this->output_postmessage_page( 'vlinkpay_error', '' );
            return;
        }

        $response = wp_remote_post( $redeem_endpoint, array(
            'method'  => 'POST',
            'headers' => array(
                'Content-Type' => 'application/json',
                'Api-key'      => $this->client_id,
            ),
            'body'    => wp_json_encode( array(
                'redeemCode'        => $redeem_code,
                'merchantOrderCode' => (string) $order_id,
            ) ),
            'timeout' => self::API_TIMEOUT,
        ) );

        $http_code = (int) wp_remote_retrieve_response_code( $response );

        if ( ! is_wp_error( $response ) && 200 === $http_code ) {
            if ( ! $order->has_status( array( 'processing', 'completed' ) ) ) {
                $order->payment_complete();
                $order->add_order_note( __( 'VLinkPay payment completed. Redeem code applied successfully.', 'vlinkpay-gateway' ) );
                WC()->cart->empty_cart();
            }
        } else {
            $error_message = is_wp_error( $response )
                ? $response->get_error_message()
                : 'HTTP ' . $http_code;
            error_log( sprintf(
                '[VLinkPay] Redeem API failed for order #%d. Error: %s. redeemCode: %s.',
                $order_id,
                $error_message,
                $redeem_code
            ) );
            $order->update_status( 'on-hold', __( 'redeemCode received but redeem API failed — manual redemption required.', 'vlinkpay-gateway' ) );
        }

        $this->output_postmessage_page( 'vlinkpay_complete', $order->get_checkout_order_received_url() );
    }

    // === Utilities ===

    /**
     * Outputs a minimal HTML page that posts a message to the parent window.
     *
     * Used by the return handler to communicate payment status back to the
     * launch page iframe container. Terminates execution via exit.
     *
     * @param  string $action   Action string sent in the postMessage data ('vlinkpay_complete' or 'vlinkpay_error').
     * @param  string $redirect URL the parent window should navigate to, or empty string.
     * @return void
     */
    private function output_postmessage_page( $action, $redirect ) {
        $data   = wp_json_encode(
            array(
                'action'   => $action,
                'redirect' => $redirect,
            ),
            JSON_HEX_TAG | JSON_HEX_AMP
        );
        $origin = esc_js( home_url() );
        ?>
        <!DOCTYPE html>
        <html>
        <head><meta charset="utf-8"></head>
        <body>
        <script>
            window.parent.postMessage(<?php echo $data; ?>, '<?php echo $origin; ?>');
        </script>
        </body>
        </html>
        <?php
        exit;
    }
}
