<?php
/**
 * Plugin Name: VLinkPay WooCommerce Gateway
 * Plugin URI: https://vlinkpay.com
 * Description: Integrate VLinkPay Payment Gateway into WooCommerce.
 * Version: 1.0.0
 * Author: Your Name
 * License: GPLv2 or later
 * Text Domain: vlinkpay-gateway
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'VLINKPAY_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'VLINKPAY_BASE_URL', 'https://vlinkpay.com' );

define( 'VLINKPAY_ACTION_LAUNCH', 'launch' );
define( 'VLINKPAY_ACTION_RETURN', 'return' );

add_action( 'plugins_loaded', 'vlinkpay_define_callback_base', 1 );
add_action( 'plugins_loaded', 'init_vlinkpay_gateway_class' );

/**
 * Defines the VLINKPAY_CALLBACK_BASE constant on plugins_loaded.
 *
 * Defers the call to home_url() until WordPress is fully bootstrapped.
 * Respects the VLINKPAY_CALLBACK_BASE environment variable if set.
 *
 * @return void
 */
function vlinkpay_define_callback_base() {
    if ( defined( 'VLINKPAY_CALLBACK_BASE' ) ) {
        return;
    }
    $env = getenv( 'VLINKPAY_CALLBACK_BASE' );
    define( 'VLINKPAY_CALLBACK_BASE', $env ? $env : home_url() );
}

/**
 * Loads the VLinkPay gateway class and registers it with WooCommerce.
 *
 * Hooked to plugins_loaded. Bails early if WooCommerce is not active.
 *
 * @return void
 */
function init_vlinkpay_gateway_class() {
    if ( ! class_exists( 'WooCommerce' ) ) {
        return;
    }
    require_once plugin_dir_path( __FILE__ ) . 'includes/class-wc-gateway-vlinkpay.php';
    add_filter( 'woocommerce_payment_gateways', 'add_vlinkpay_gateway_to_woocommerce' );
}

/**
 * Adds the VLinkPay gateway to WooCommerce's list of payment gateways.
 *
 * @param  array $gateways Existing list of gateway class names.
 * @return array           Updated list with WC_Gateway_VLinkPay appended.
 */
function add_vlinkpay_gateway_to_woocommerce( $gateways ) {
    $gateways[] = 'WC_Gateway_VLinkPay';
    return $gateways;
}

// Use template_redirect instead of woocommerce_api_* to avoid WooCommerce's
// ob_start()/ob_end_clean() wrapper which can swallow our HTML output in
// some Nginx/PHP-FPM configurations.
add_action( 'template_redirect', 'vlinkpay_handle_requests', 1 );

/**
 * Routes incoming vlinkpay_action query-string requests to the gateway handler.
 *
 * Hooked to template_redirect at priority 1. Handles 'launch' and 'return'
 * actions and exits after processing to prevent theme template output.
 *
 * @return void
 */
function vlinkpay_handle_requests() {
    if ( empty( $_GET['vlinkpay_action'] ) ) {
        return;
    }

    if ( ! class_exists( 'WC_Gateway_VLinkPay' ) ) {
        require_once plugin_dir_path( __FILE__ ) . 'includes/class-wc-gateway-vlinkpay.php';
    }

    $gateway = new WC_Gateway_VLinkPay();
    $action  = sanitize_key( $_GET['vlinkpay_action'] );

    if ( VLINKPAY_ACTION_LAUNCH === $action ) {
        $gateway->handle_vlinkpay_launch();
    } elseif ( VLINKPAY_ACTION_RETURN === $action ) {
        $gateway->handle_vlinkpay_return();
    }

    exit;
}
