jQuery(function ($) {

    // Intercept WooCommerce's checkout success response.
    // If the redirect URL points to VLinkPay's embedded page, open it in a modal
    // iframe instead of navigating the full page. Setting result.redirect to a
    // hash prevents WooCommerce from doing a hard redirect after our handler runs.
    $(document.body).on('checkout_place_order_success', function (e, result) {
        if (result.redirect && result.redirect.indexOf('vlinkpay.com/embedded') !== -1) {
            var paymentUrl = result.redirect;
            result.redirect = '#vlinkpay-processing';
            openModal(paymentUrl);
        }
    });

    function openModal(url) {
        var $modal = $(
            '<div id="vlinkpay-modal-overlay">' +
                '<div id="vlinkpay-modal-box">' +
                    '<div id="vlinkpay-spinner"><div class="vlinkpay-spin"></div></div>' +
                    '<iframe id="vlinkpay-iframe" src="' + url + '" allowpaymentrequest></iframe>' +
                '</div>' +
            '</div>' +
            '<style>' +
                '#vlinkpay-modal-overlay{position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,.6);z-index:999999;display:flex;align-items:center;justify-content:center;}' +
                '#vlinkpay-modal-box{position:relative;width:90%;max-width:520px;height:80vh;background:#fff;border-radius:8px;overflow:hidden;}' +
                '#vlinkpay-spinner{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;background:#fff;z-index:2;}' +
                '.vlinkpay-spin{width:48px;height:48px;border:4px solid #e5e7eb;border-top-color:#2563eb;border-radius:50%;animation:vlinkpay-spin .8s linear infinite;}' +
                '@keyframes vlinkpay-spin{to{transform:rotate(360deg)}}' +
                '#vlinkpay-iframe{position:absolute;inset:0;width:100%;height:100%;border:none;z-index:1;}' +
            '</style>'
        );

        $('body').append($modal);

        $('#vlinkpay-iframe').on('load', function () {
            $('#vlinkpay-spinner').fadeOut(200);
        });
    }

    // Listen for the postMessage sent by the return handler page loaded in the iframe.
    window.addEventListener('message', function (e) {
        if (e.origin !== window.location.origin) {
            return;
        }
        var data = e.data;
        if (!data || !data.action) {
            return;
        }
        if (data.action === 'vlinkpay_complete' || data.action === 'vlinkpay_error') {
            $('#vlinkpay-modal-overlay').remove();
            if (data.redirect) {
                window.location.href = data.redirect;
            }
        }
    });

});
